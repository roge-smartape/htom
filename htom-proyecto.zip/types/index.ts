export interface HeroFormData {
  nombre: string
  apellido: string
  email: string
  statusAcademico: string
}

export interface RegistroFormData {
  nombres: string
  apellidos: string
  email: string
  telefono: string
  nivelIngles: string
  aceptaTerminos: boolean
}
